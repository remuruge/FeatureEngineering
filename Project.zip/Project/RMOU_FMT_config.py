DATASET_PATH = '/Users/rm185431/GL/ML/Featurisation/Project/'
DATASET_NAME = 'concrete.csv'
TEST_SIZE = 0.3
SPLIT_RANDOM_STATE = 9