import numpy as np
import pandas as pd

class Utilities:
    
    def __init__(self, input_path, input_dataset):
        self.input_path = input_path
        self.input_dataset = input_dataset

    # Load the Dataset
    def load_data(self):
        # Function loads data for training
        return pd.read_csv(self.input_dataset)
    
    