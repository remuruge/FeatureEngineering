import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


import RMOU_FMT_config as cf


class PrepData:
    
    def __init__(self, input_df, target):
            
            # data sets
            self.input_df = input_df
            self.target = target
            self.X_train = None
            self.X_test = None
            self.y_train = None
            self.y_test = None
            
            # engineering parameters (to be learnt from data)
            self.imputing_num_dict = {}
            self.imputing_cat_dict = {}
            self.outlier_dict = {}
            self.frequent_category_dict = {}
            self.encoding_dict = {}
            self.unique_val_dict = {}
        
            # models
            self.scaler = StandardScaler()
            
            
    def split_df_train_test(self, testSize=0.3, randomState=1234):
            return train_test_split(
                self.input_df.loc[:, self.input_df.columns != self.target], 
                self.input_df[self.target],
                test_size=testSize, random_state=randomState)
        
    def find_numeric_missing(self):
        for variable in self.numerical_to_impute:
            replacement = self.X_train[variable].median()
            self.imputing_num_dict[variable] = replacement
        return self
    
    def find_outliers(self, floor=0.25, capp=0.75):
        for variable in self.input_df.columns:
            q1 = self.input_df[variable].quantile(floor)
            q3 = self.input_df[variable].quantile(capp)
            iqr = q3-q1 #Interquartile range
            fence_low  = q1-1.5*iqr
            fence_high = q3+1.5*iqr
            self.outlier_dict[variable] = (fence_low, fence_high, self.input_df[variable].skew())
        return self
    
    def fill_outliers_median(self, df, col_name):
        q1 = df[col_name].quantile(0.25)
        q3 = df[col_name].quantile(0.75)
        iqr = q3-q1 #Interquartile range
        fence_low  = q1-1.5*iqr
        fence_high = q3+1.5*iqr
        df[col_name] = np.where(((df[col_name] < fence_low) | (df[col_name] > fence_high)), df[col_name].median(), df[col_name])
        return df[col_name]
    
    def fill_outliers_floor_capp(self, df, col_name, floor=0.25, capp=0.75):
        q1 = df[col_name].quantile(floor)
        q3 = df[col_name].quantile(capp)
        df[col_name] = np.where((df[col_name] < q1), q1, df[col_name])
        df[col_name] = np.where((df[col_name] > q3), q3, df[col_name])
        return df[col_name]